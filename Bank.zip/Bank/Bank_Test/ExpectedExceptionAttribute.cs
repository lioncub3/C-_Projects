﻿using System;

namespace Bank_Test
{
    internal class ExpectedExceptionAttribute : Attribute
    {
    }
}